//! Settings: one JSON file in the app config directory.

use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::Path;

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default)]
pub struct Settings {
    /// UDP port VMC senders send to.
    pub port: u16,
    /// "dark", "green" or "clear".
    pub background: String,
    pub mirror: bool,
    /// 0 = bust-up, 1 = full body.
    pub zoom: f32,
    /// Hold the pelvis level (seated streaming).
    pub seated: bool,
    /// Path of the last loaded model.
    pub model: Option<String>,
    /// Calibration: the rotation of each posture bone (x, y, z, w) that counts as straight.
    pub neutral: HashMap<String, [f32; 4]>,
}

impl Default for Settings {
    fn default() -> Self {
        Self { port: 39539, background: "dark".into(), mirror: false, zoom: 0.0, seated: false, model: None, neutral: HashMap::new() }
    }
}

/// Missing or unreadable files give defaults.
pub fn load(path: &Path) -> Settings {
    std::fs::read_to_string(path)
        .ok()
        .and_then(|t| serde_json::from_str(&t).ok())
        .unwrap_or_default()
}

pub fn save(path: &Path, settings: &Settings) -> std::io::Result<()> {
    if let Some(dir) = path.parent() {
        std::fs::create_dir_all(dir)?;
    }
    let text = serde_json::to_string_pretty(settings).map_err(std::io::Error::other)?;
    std::fs::write(path, text)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn temp(name: &str) -> std::path::PathBuf {
        std::env::temp_dir().join(format!("puppet-test-{}-{name}", std::process::id()))
    }

    #[test]
    fn roundtrip() {
        let path = temp("settings.json");
        let s = Settings { port: 40000, background: "green".into(), mirror: true, zoom: 0.6, seated: true, model: Some("/a/b.vrm".into()), neutral: HashMap::from([("Head".to_string(), [0.0, 0.05, 0.0, 0.9987])]) };
        save(&path, &s).unwrap();
        assert_eq!(load(&path), s);
        let _ = std::fs::remove_file(path);
    }

    #[test]
    fn accepts_what_the_ui_sends() {
        // Exactly the shape the web UI saves, including a calibration and an integer zoom.
        let json = r#"{"port":39539,"background":"green","mirror":false,"zoom":0,"seated":true,"model":null,
                       "neutral":{"Head":[0,0,0.0523,0.9986],"Spine":[0.1,0,0,0.995]}}"#;
        let s: Settings = serde_json::from_str(json).unwrap();
        assert_eq!(s.neutral.len(), 2);
        assert_eq!(s.neutral["Head"], [0.0, 0.0, 0.0523, 0.9986]);
        assert_eq!(s.background, "green");
        assert!(s.seated);
    }

    #[test]
    fn missing_corrupt_and_partial_files_give_defaults() {
        assert_eq!(load(&temp("missing.json")), Settings::default());
        let path = temp("corrupt.json");
        std::fs::write(&path, "{not json").unwrap();
        assert_eq!(load(&path), Settings::default());
        std::fs::write(&path, r#"{"mirror": true}"#).unwrap();
        let s = load(&path);
        assert!(s.mirror);
        assert_eq!(s.port, 39539);
        let _ = std::fs::remove_file(path);
    }
}
