#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod settings;
mod vmc;

use serde::Serialize;
use settings::Settings;
use std::io::Write;
use std::path::PathBuf;
use std::sync::atomic::Ordering;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};
use tauri::{Emitter, Manager, State};
use tauri_plugin_dialog::DialogExt;

struct AppState {
    settings: Mutex<Settings>,
    path: PathBuf,
    /// `--vrm` overrides the remembered model for this run.
    cli_model: Option<String>,
}

#[derive(Default)]
struct Cli {
    port: Option<u16>,
    vrm: Option<String>,
    record: Option<PathBuf>,
    replay: Option<PathBuf>,
}

fn parse_cli(args: impl Iterator<Item = String>) -> Cli {
    let mut cli = Cli::default();
    let mut args = args.skip(1);
    while let Some(arg) = args.next() {
        match arg.as_str() {
            "--port" => cli.port = args.next().and_then(|v| v.parse().ok()),
            "--vrm" => {
                // Absolute, so the remembered model still opens from any folder.
                cli.vrm = args.next().map(|p| std::path::absolute(&p).map(|a| a.to_string_lossy().into_owned()).unwrap_or(p))
            }
            "--record" => cli.record = args.next().map(PathBuf::from),
            "--replay" => cli.replay = args.next().map(PathBuf::from),
            _ => {}
        }
    }
    cli
}

#[derive(Serialize, Clone)]
struct Status {
    addr: String,
    live: bool,
    error: Option<String>,
}

#[tauri::command]
fn settings_get(state: State<AppState>) -> Settings {
    let mut s = state.settings.lock().unwrap().clone();
    if state.cli_model.is_some() {
        s.model = state.cli_model.clone();
    }
    s
}

#[tauri::command]
fn settings_set(state: State<AppState>, settings: Settings) -> Result<(), String> {
    settings::save(&state.path, &settings).map_err(|e| e.to_string())?;
    *state.settings.lock().unwrap() = settings;
    Ok(())
}

#[tauri::command]
fn load_model(path: String) -> Result<tauri::ipc::Response, String> {
    std::fs::read(&path)
        .map(tauri::ipc::Response::new)
        .map_err(|e| format!("{path}: {e}"))
}

#[tauri::command]
async fn pick_model(app: tauri::AppHandle) -> Option<String> {
    app.dialog()
        .file()
        .add_filter("VRM", &["vrm"])
        .blocking_pick_file()
        .and_then(|p| p.into_path().ok())
        .map(|p| p.to_string_lossy().into_owned())
}

fn main() {
    let cli = parse_cli(std::env::args());

    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .invoke_handler(tauri::generate_handler![settings_get, settings_set, load_model, pick_model])
        .on_window_event(|window, event| {
            if let tauri::WindowEvent::DragDrop(tauri::DragDropEvent::Drop { paths, .. }) = event {
                if let Some(path) = paths.first() {
                    let _ = window.emit("drop", path.to_string_lossy().into_owned());
                }
            }
        })
        .setup(move |app| {
            let path = app.path().app_config_dir()?.join("settings.json");
            let settings = settings::load(&path);
            let port = cli.port.unwrap_or(settings.port);
            app.manage(AppState {
                settings: Mutex::new(settings),
                path,
                cli_model: cli.vrm.clone(),
            });

            let shared = Arc::new(vmc::Shared::default());
            if let Some(file) = &cli.replay {
                let text = std::fs::read_to_string(file)?;
                vmc::spawn_replay(shared.clone(), vmc::parse_recording(&text));
            } else {
                match vmc::bind(port) {
                    Ok(socket) => vmc::spawn_receiver(shared.clone(), socket),
                    Err(_) => *shared.error.lock().unwrap() = Some(format!(":{port} busy")),
                }
            }

            let handle = app.handle().clone();
            let record = cli.record.clone();
            std::thread::spawn(move || {
                let mut recorder = record.and_then(|p| std::fs::File::create(p).ok());
                let mut t0: Option<Instant> = None;
                let mut last_status = Instant::now() - Duration::from_secs(1);
                loop {
                    std::thread::sleep(Duration::from_millis(16));
                    if shared.dirty.swap(false, Ordering::Acquire) {
                        let frame = shared.frame.lock().unwrap().clone();
                        let _ = handle.emit("frame", &frame);
                        if let Some(file) = recorder.as_mut() {
                            let t = t0.get_or_insert_with(Instant::now).elapsed().as_millis() as u64;
                            let _ = writeln!(file, "{}", vmc::record_line(t, &frame));
                        }
                    }
                    if last_status.elapsed() >= Duration::from_millis(500) {
                        last_status = Instant::now();
                        let _ = handle.emit(
                            "status",
                            Status {
                                addr: format!("{}:{}", vmc::local_ip(), port),
                                live: shared.is_live(),
                                error: shared.error.lock().unwrap().clone(),
                            },
                        );
                    }
                }
            });
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("failed to run Puppet");
}

#[cfg(test)]
mod tests {
    use super::*;

    fn args(list: &[&str]) -> impl Iterator<Item = String> {
        std::iter::once("puppet".to_string()).chain(list.iter().map(|s| s.to_string())).collect::<Vec<_>>().into_iter()
    }

    #[test]
    fn parses_flags() {
        let cli = parse_cli(args(&["--port", "40001", "--vrm", "a.vrm", "--record", "r.jsonl", "--replay", "p.jsonl"]));
        assert_eq!(cli.port, Some(40001));
        let vrm = PathBuf::from(cli.vrm.unwrap());
        assert!(vrm.is_absolute() && vrm.ends_with("a.vrm"));
        assert_eq!(cli.record, Some(PathBuf::from("r.jsonl")));
        assert_eq!(cli.replay, Some(PathBuf::from("p.jsonl")));
    }

    #[test]
    fn ignores_unknown_and_bad_values() {
        let cli = parse_cli(args(&["--port", "nope", "--wat", "-x"]));
        assert_eq!(cli.port, None);
        assert!(cli.vrm.is_none() && cli.record.is_none() && cli.replay.is_none());
    }
}
