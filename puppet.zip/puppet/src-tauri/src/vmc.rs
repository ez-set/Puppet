//! VMC (OSC over UDP) decoding and the receiver that keeps the latest frame.

use rosc::{OscMessage, OscPacket, OscType};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::net::UdpSocket;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

/// How long after the last packet the sender still counts as live.
pub const LIVE_WINDOW: Duration = Duration::from_millis(1000);

/// Latest pose: bone rotations (Unity humanoid names, quaternion x y z w) and blendshape weights.
/// Positions are never used.
#[derive(Default, Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Frame {
    pub bones: HashMap<String, [f32; 4]>,
    pub blends: HashMap<String, f32>,
}

/// Merge one UDP datagram into `frame`. Returns true if it carried bone or blendshape data.
pub fn decode(datagram: &[u8], frame: &mut Frame) -> bool {
    match rosc::decoder::decode_udp(datagram) {
        Ok((_, packet)) => apply(packet, frame),
        Err(_) => false,
    }
}

fn apply(packet: OscPacket, frame: &mut Frame) -> bool {
    match packet {
        OscPacket::Message(m) => apply_message(m, frame),
        OscPacket::Bundle(b) => b
            .content
            .into_iter()
            .fold(false, |changed, p| apply(p, frame) | changed),
    }
}

fn apply_message(m: OscMessage, frame: &mut Frame) -> bool {
    match (m.addr.as_str(), m.args.as_slice()) {
        (
            "/VMC/Ext/Bone/Pos",
            [OscType::String(name), _, _, _, OscType::Float(x), OscType::Float(y), OscType::Float(z), OscType::Float(w)],
        ) => {
            frame.bones.insert(name.clone(), [*x, *y, *z, *w]);
            true
        }
        ("/VMC/Ext/Blend/Val", [OscType::String(name), OscType::Float(v)]) => {
            frame.blends.insert(name.clone(), *v);
            true
        }
        _ => false,
    }
}

/// State shared between the receiver thread and the emitter.
#[derive(Default)]
pub struct Shared {
    pub frame: Mutex<Frame>,
    pub dirty: AtomicBool,
    pub last_packet: Mutex<Option<Instant>>,
    pub error: Mutex<Option<String>>,
}

impl Shared {
    pub fn set_frame(&self, frame: Frame) {
        *self.frame.lock().unwrap() = frame;
        self.touch();
    }

    fn touch(&self) {
        *self.last_packet.lock().unwrap() = Some(Instant::now());
        self.dirty.store(true, Ordering::Release);
    }

    pub fn is_live(&self) -> bool {
        self.last_packet
            .lock()
            .unwrap()
            .map(|t| t.elapsed() < LIVE_WINDOW)
            .unwrap_or(false)
    }
}

pub fn bind(port: u16) -> std::io::Result<UdpSocket> {
    let socket = UdpSocket::bind(("0.0.0.0", port))?;
    socket.set_read_timeout(Some(Duration::from_millis(200)))?;
    Ok(socket)
}

/// Receive datagrams forever, merging them into `shared`.
pub fn spawn_receiver(shared: Arc<Shared>, socket: UdpSocket) {
    std::thread::spawn(move || {
        let mut buf = vec![0u8; 65536];
        loop {
            let Ok(n) = socket.recv(&mut buf) else { continue };
            let changed = decode(&buf[..n], &mut shared.frame.lock().unwrap());
            if changed {
                shared.touch();
            }
        }
    });
}

/// One line of a recording: `{"t": <ms>, "frame": {...}}`.
#[derive(Serialize, Deserialize)]
pub struct Line {
    pub t: u64,
    pub frame: Frame,
}

pub fn record_line(t_ms: u64, frame: &Frame) -> String {
    serde_json::to_string(&Line { t: t_ms, frame: frame.clone() }).unwrap()
}

pub fn parse_recording(text: &str) -> Vec<Line> {
    text.lines()
        .filter_map(|l| serde_json::from_str::<Line>(l).ok())
        .collect()
}

/// Loop a recording into `shared` as if a sender were live.
pub fn spawn_replay(shared: Arc<Shared>, lines: Vec<Line>) {
    std::thread::spawn(move || {
        if lines.is_empty() {
            return;
        }
        loop {
            let start = Instant::now();
            for line in &lines {
                let due = Duration::from_millis(line.t);
                if let Some(wait) = due.checked_sub(start.elapsed()) {
                    std::thread::sleep(wait);
                }
                shared.set_frame(line.frame.clone());
            }
        }
    });
}

/// The address a phone on the same network should send to (default-route interface).
pub fn local_ip() -> String {
    UdpSocket::bind("0.0.0.0:0")
        .and_then(|s| {
            s.connect("192.0.2.1:9")?; // no packet is sent
            s.local_addr()
        })
        .map(|a| a.ip().to_string())
        .unwrap_or_else(|_| "127.0.0.1".to_string())
}

#[cfg(test)]
mod tests {
    use super::*;
    use rosc::{encoder, OscBundle, OscTime};

    fn bone(name: &str, q: [f32; 4]) -> OscPacket {
        OscPacket::Message(OscMessage {
            addr: "/VMC/Ext/Bone/Pos".into(),
            args: vec![
                OscType::String(name.into()),
                OscType::Float(1.0),
                OscType::Float(2.0),
                OscType::Float(3.0),
                OscType::Float(q[0]),
                OscType::Float(q[1]),
                OscType::Float(q[2]),
                OscType::Float(q[3]),
            ],
        })
    }

    fn blend(name: &str, v: f32) -> OscPacket {
        OscPacket::Message(OscMessage {
            addr: "/VMC/Ext/Blend/Val".into(),
            args: vec![OscType::String(name.into()), OscType::Float(v)],
        })
    }

    fn bundle(content: Vec<OscPacket>) -> Vec<u8> {
        encoder::encode(&OscPacket::Bundle(OscBundle {
            timetag: OscTime { seconds: 0, fractional: 1 },
            content,
        }))
        .unwrap()
    }

    #[test]
    fn decodes_bones_and_blends_from_a_bundle() {
        let data = bundle(vec![
            bone("LeftUpperArm", [-0.113, 0.216, 0.306, 0.920]),
            blend("jawOpen", 0.4),
            OscPacket::Message(OscMessage { addr: "/VMC/Ext/OK".into(), args: vec![OscType::Float(1.0)] }),
        ]);
        let mut f = Frame::default();
        assert!(decode(&data, &mut f));
        assert_eq!(f.bones["LeftUpperArm"], [-0.113, 0.216, 0.306, 0.920]);
        assert_eq!(f.blends["jawOpen"], 0.4);
    }

    #[test]
    fn later_messages_overwrite_and_others_persist() {
        let mut f = Frame::default();
        decode(&bundle(vec![bone("Head", [0.0, 0.0, 0.0, 1.0]), bone("Spine", [0.1, 0.0, 0.0, 0.995])]), &mut f);
        decode(&bundle(vec![bone("Head", [0.0, 0.2, 0.0, 0.98])]), &mut f);
        assert_eq!(f.bones["Head"], [0.0, 0.2, 0.0, 0.98]);
        assert_eq!(f.bones["Spine"], [0.1, 0.0, 0.0, 0.995]);
    }

    #[test]
    fn ignores_garbage_and_unrelated_messages() {
        let mut f = Frame::default();
        assert!(!decode(b"not osc at all", &mut f));
        assert!(!decode(&[], &mut f));
        let other = encoder::encode(&OscPacket::Message(OscMessage {
            addr: "/VMC/Ext/Root/Pos".into(),
            args: vec![OscType::String("root".into())],
        }))
        .unwrap();
        assert!(!decode(&other, &mut f));
        // A bone message with the wrong shape is skipped, not a panic.
        let bad = encoder::encode(&OscPacket::Message(OscMessage {
            addr: "/VMC/Ext/Bone/Pos".into(),
            args: vec![OscType::String("Head".into())],
        }))
        .unwrap();
        assert!(!decode(&bad, &mut f));
        assert_eq!(f, Frame::default());
    }

    #[test]
    fn udp_loopback_reaches_shared_state() {
        let socket = bind(0).unwrap();
        let port = socket.local_addr().unwrap().port();
        let shared = Arc::new(Shared::default());
        assert!(!shared.is_live());
        spawn_receiver(shared.clone(), socket);

        let sender = UdpSocket::bind("127.0.0.1:0").unwrap();
        let data = bundle(vec![bone("RightLowerArm", [0.132, -0.558, 0.141, 0.807]), blend("eyeBlinkLeft", 0.9)]);
        sender.send_to(&data, ("127.0.0.1", port)).unwrap();

        let start = Instant::now();
        while !shared.is_live() && start.elapsed() < Duration::from_secs(3) {
            std::thread::sleep(Duration::from_millis(10));
        }
        assert!(shared.is_live());
        assert!(shared.dirty.load(Ordering::Acquire));
        let f = shared.frame.lock().unwrap();
        assert_eq!(f.bones["RightLowerArm"], [0.132, -0.558, 0.141, 0.807]);
        assert_eq!(f.blends["eyeBlinkLeft"], 0.9);
    }

    #[test]
    fn recording_roundtrips() {
        let mut f = Frame::default();
        f.bones.insert("Head".into(), [0.0, 0.1, 0.0, 0.995]);
        f.blends.insert("jawOpen".into(), 0.25);
        let text = format!("{}\n{}\n", record_line(0, &f), record_line(16, &f));
        let lines = parse_recording(&text);
        assert_eq!(lines.len(), 2);
        assert_eq!(lines[1].t, 16);
        assert_eq!(lines[0].frame, f);
        // Blank or corrupt lines are skipped.
        assert_eq!(parse_recording("\nnope\n").len(), 0);
    }

    #[test]
    fn replay_drives_shared_state() {
        let mut f = Frame::default();
        f.bones.insert("Spine".into(), [0.1, 0.0, 0.0, 0.995]);
        let shared = Arc::new(Shared::default());
        spawn_replay(shared.clone(), vec![Line { t: 0, frame: f.clone() }]);
        let start = Instant::now();
        while !shared.is_live() && start.elapsed() < Duration::from_secs(3) {
            std::thread::sleep(Duration::from_millis(10));
        }
        assert_eq!(*shared.frame.lock().unwrap(), f);
    }

    #[test]
    fn local_ip_is_an_address() {
        assert!(local_ip().parse::<std::net::IpAddr>().is_ok());
    }
}
