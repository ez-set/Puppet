#!/usr/bin/env python3
"""Build fixtures/selfreflect.jsonl.

Bone rotations are one real SelfReflect frame (captured with a VMC probe); the motion is
synthetic: the right forearm swings, the jaw opens, and both eyes blink once.
Format: one {"t": ms, "frame": {"bones": {...}, "blends": {...}}} object per line,
the same format `puppet --record` writes.
"""
import json, math, pathlib

BONES = {
 "Hips": [0.022,-0.055,0.055,-0.997], "OriginalHips": [0.022,-0.055,0.055,-0.997],
 "Spine": [0.113,0.001,-0.010,0.994], "Chest": [0.051,-0.001,-0.008,0.999], "UpperChest": [-0.007,0.000,0.003,1.000],
 "Neck": [0.150,-0.035,0.062,0.986], "Head": [-0.392,-0.035,0.060,0.917],
 "LeftShoulder": [-0.043,0.137,-0.019,0.990], "LeftUpperArm": [-0.113,0.216,0.306,0.920],
 "LeftLowerArm": [-0.020,0.442,-0.165,0.881], "LeftHand": [-0.059,-0.071,-0.054,0.994],
 "LeftThumbProximal": [-0.028,-0.188,-0.051,0.981], "LeftThumbIntermediate": [-0.011,-0.031,-0.027,0.999], "LeftThumbDistal": [0.060,-0.068,0.021,0.996],
 "LeftIndexProximal": [0.024,-0.025,0.013,0.999], "LeftIndexIntermediate": [0.018,-0.009,0.273,0.962], "LeftIndexDistal": [0.002,0.008,0.162,0.987],
 "LeftMiddleProximal": [-0.032,-0.040,0.134,0.990], "LeftMiddleIntermediate": [0.017,0.030,0.355,0.934], "LeftMiddleDistal": [-0.015,0.047,0.226,0.973],
 "LeftRingProximal": [-0.027,-0.005,0.193,0.981], "LeftRingIntermediate": [-0.019,0.060,0.303,0.951], "LeftRingDistal": [-0.021,0.032,0.148,0.988],
 "LeftLittleProximal": [-0.070,-0.026,0.290,0.954], "LeftLittleIntermediate": [-0.022,0.027,0.244,0.969], "LeftLittleDistal": [-0.051,0.007,0.098,0.994],
 "RightShoulder": [0.008,-0.143,-0.060,0.988], "RightUpperArm": [0.058,-0.187,-0.473,0.859],
 "RightLowerArm": [0.132,-0.558,0.141,0.807], "RightHand": [-0.049,-0.040,-0.067,-0.996],
 "RightThumbProximal": [0.000,0.173,0.051,0.984], "RightThumbIntermediate": [-0.026,0.022,0.007,0.999], "RightThumbDistal": [0.053,0.080,-0.013,0.995],
 "RightIndexProximal": [-0.010,0.025,0.035,0.999], "RightIndexIntermediate": [0.025,-0.004,-0.279,0.960], "RightIndexDistal": [-0.022,-0.023,-0.169,0.985],
 "RightMiddleProximal": [-0.028,0.063,-0.098,0.993], "RightMiddleIntermediate": [0.027,-0.010,-0.297,0.955], "RightMiddleDistal": [-0.021,-0.043,-0.195,0.980],
 "RightRingProximal": [0.002,0.016,-0.095,0.995], "RightRingIntermediate": [-0.014,-0.044,-0.288,0.956], "RightRingDistal": [-0.013,-0.025,-0.137,0.990],
 "RightLittleProximal": [-0.056,0.078,-0.197,0.976], "RightLittleIntermediate": [-0.013,-0.018,-0.247,0.969], "RightLittleDistal": [-0.062,0.010,-0.115,0.991],
 "LeftUpperLeg": [-0.423,-0.029,-0.056,0.904], "LeftLowerLeg": [0.616,-0.075,0.034,0.783], "LeftFoot": [-0.486,0.011,-0.025,0.874], "LeftToes": [-0.060,0.145,-0.008,0.988],
 "RightUpperLeg": [-0.480,-0.018,0.052,0.876], "RightLowerLeg": [0.647,0.059,-0.016,0.760], "RightFoot": [-0.474,-0.039,-0.007,0.880], "RightToes": [-0.063,-0.149,0.028,0.986],
 "LeftEye": [0.069,-0.081,-0.025,0.994], "RightEye": [0.069,-0.081,-0.025,0.994],
}

def axis_y(deg):
    h = math.radians(deg) / 2
    return [0, math.sin(h), 0, math.cos(h)]

def qmul(a, b):
    ax, ay, az, aw = a; bx, by, bz, bw = b
    return [aw*bx+ax*bw+ay*bz-az*by, aw*by-ax*bz+ay*bw+az*bx, aw*bz+ax*by-ay*bx+az*bw, aw*bw-ax*bx-ay*by-az*bz]

lines = []
for i in range(91):  # 3 s at 30 fps
    t = i * 1000 // 30
    s = i / 30
    bones = {k: list(v) for k, v in BONES.items()}
    bones["RightLowerArm"] = qmul(BONES["RightLowerArm"], axis_y(-35 * math.sin(s * 2 * math.pi * 0.8)))
    blink = 1.0 if 1.4 < s < 1.55 else 0.0
    blends = {"jawOpen": round(0.35 * (0.5 + 0.5 * math.sin(s * 2 * math.pi * 1.5)), 3),
              "eyeBlinkLeft": blink, "eyeBlinkRight": blink}
    lines.append(json.dumps({"t": t, "frame": {"bones": bones, "blends": blends}}, separators=(",", ":")))

out = pathlib.Path(__file__).resolve().parent.parent / "fixtures" / "selfreflect.jsonl"
out.write_text("\n".join(lines) + "\n")
print(f"{out}: {len(lines)} frames")
