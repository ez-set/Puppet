#!/usr/bin/env python3
"""Play a recording to a VMC receiver as real UDP packets, like SelfReflect would.

    python3 scripts/send_fixture.py [recording.jsonl] [host] [port]

Defaults: fixtures/selfreflect.jsonl 127.0.0.1 39539. Loops until Ctrl-C.
"""
import json, pathlib, socket, struct, sys, time


def pad(b: bytes) -> bytes:
    b += b"\x00"
    return b + b"\x00" * (-len(b) % 4)


def message(addr: str, tags: str, *args) -> bytes:
    out = pad(addr.encode()) + pad(("," + tags).encode())
    for t, a in zip(tags, args):
        out += struct.pack(">f", a) if t == "f" else pad(a.encode())
    return out


def bundle(messages) -> bytes:
    out = b"#bundle\x00" + struct.pack(">Q", 1)
    for m in messages:
        out += struct.pack(">i", len(m)) + m
    return out


def packet(frame) -> bytes:
    msgs = [message("/VMC/Ext/Bone/Pos", "sfffffff", name, 0, 0, 0, *q) for name, q in frame["bones"].items()]
    msgs += [message("/VMC/Ext/Blend/Val", "sf", name, v) for name, v in frame["blends"].items()]
    msgs += [message("/VMC/Ext/Blend/Apply", ""), message("/VMC/Ext/OK", "f", 1.0)]
    return bundle(msgs)


def main():
    root = pathlib.Path(__file__).resolve().parent.parent
    path = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else root / "fixtures" / "selfreflect.jsonl"
    host = sys.argv[2] if len(sys.argv) > 2 else "127.0.0.1"
    port = int(sys.argv[3]) if len(sys.argv) > 3 else 39539
    lines = [json.loads(l) for l in path.read_text().splitlines() if l]
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    print(f"sending {len(lines)} frames to {host}:{port} (Ctrl-C to stop)")
    while True:
        start = time.time()
        for line in lines:
            time.sleep(max(0, line["t"] / 1000 - (time.time() - start)))
            sock.sendto(packet(line["frame"]), (host, port))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
