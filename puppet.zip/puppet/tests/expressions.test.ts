import { describe, expect, it } from 'vitest';
import { expressionWeights } from '../src/expressions';

const PRESETS = ['aa', 'ih', 'ou', 'ee', 'oh', 'blinkLeft', 'blinkRight', 'happy'];

describe('expressionWeights', () => {
  it('maps jaw and blink onto VRM presets', () => {
    const w = expressionWeights({ jawOpen: 0.8, eyeBlinkLeft: 1, eyeBlinkRight: 0.25 }, PRESETS);
    expect(w.aa).toBeCloseTo(0.8);
    expect(w.blinkLeft).toBe(1);
    expect(w.blinkRight).toBe(0.25);
  });

  it('falls back to a single blink when the model has no left/right', () => {
    const w = expressionWeights({ eyeBlinkLeft: 1, eyeBlinkRight: 0 }, ['aa', 'blink']);
    expect(w.blink).toBeCloseTo(0.5);
    expect(w.blinkLeft).toBeUndefined();
  });

  it('rounds the mouth for pucker and funnel', () => {
    const w = expressionWeights({ mouthPucker: 0.6, mouthFunnel: 0.4, jawOpen: 1 }, PRESETS);
    expect(w.ou).toBeCloseTo(0.6);
    expect(w.oh).toBeCloseTo(0.4);
    expect(w.aa).toBeCloseTo(0.7); // jaw reduced while puckered
  });

  it('passes ARKit weights straight through on perfect-sync models', () => {
    const names = ['eyeBlinkLeft', 'eyeBlinkRight', 'jawOpen', 'mouthSmileLeft', 'mouthSmileRight', 'browInnerUp',
      'cheekPuff', 'mouthFunnel', 'mouthPucker', 'noseSneerLeft', 'noseSneerRight', 'tongueOut', 'aa'];
    const w = expressionWeights({ jawOpen: 0.5, mouthSmileLeft: 0.7, tongueOut: 0.1 }, names);
    expect(w).toEqual({ jawOpen: 0.5, mouthSmileLeft: 0.7, tongueOut: 0.1 });
  });

  it('decides perfect-sync from the model, not from which blends a frame carries', () => {
    const names = ['eyeBlinkLeft', 'eyeBlinkRight', 'jawOpen', 'mouthSmileLeft', 'mouthSmileRight', 'browInnerUp',
      'cheekPuff', 'mouthFunnel', 'mouthPucker', 'noseSneerLeft', 'noseSneerRight', 'tongueOut', 'aa'];
    expect(expressionWeights({ jawOpen: 0.5 }, names)).toEqual({ jawOpen: 0.5 });
  });

  it('matches names case- and punctuation-insensitively', () => {
    const names = ['Jaw_Open', 'Eye_Blink_Left', 'Eye_Blink_Right', 'brow-inner-up', 'cheekPuff', 'mouthFunnel',
      'mouthPucker', 'noseSneerLeft', 'noseSneerRight', 'tongueOut', 'mouthSmileLeft', 'mouthSmileRight'];
    expect(expressionWeights({ jawOpen: 0.3 }, names).Jaw_Open).toBeCloseTo(0.3);
  });

  it('clamps to 0–1 and handles empty input', () => {
    const w = expressionWeights({ jawOpen: 4, mouthPucker: -2 }, PRESETS);
    expect(w.aa).toBeLessThanOrEqual(1);
    expect(w.ou).toBe(0);
    expect(expressionWeights({}, PRESETS).aa).toBe(0);
  });
});
