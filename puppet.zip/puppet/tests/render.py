#!/usr/bin/env python3
"""Render check: load real VRM models in headless Chromium, drive them with VMC-style
poses, and assert the avatar faces the camera and moves the right way.

    npm run build:web && python3 tests/render.py

Needs `pip install playwright && playwright install chromium`. Downloads two sample
models (VRM 1.0 and VRM 0.x) into tests/models on first run. Screenshots go to tests/shots.
"""
import functools, http.server, math, pathlib, sys, threading, urllib.parse, urllib.request
from playwright.sync_api import sync_playwright

ROOT = pathlib.Path(__file__).resolve().parent.parent
MODELS = {
    "VRM1": ("Constraint_Twist_Sample.vrm",
             "https://raw.githubusercontent.com/vrm-c/vrm-specification/master/samples/VRM1_Constraint_Twist_Sample/vrm/VRM1_Constraint_Twist_Sample.vrm"),
    "VRM0": ("AliciaSolid.vrm",
             "https://raw.githubusercontent.com/vrm-c/UniVRM/master/Tests/Models/Alicia_vrm-0.51/AliciaSolid_vrm-0.51.vrm"),
}
SHOTS = ROOT / "tests" / "shots"
SHOTS.mkdir(exist_ok=True)
failures = []


def check(cond, label, detail=""):
    print(("  ok   " if cond else "  FAIL ") + label + (f"  [{detail}]" if detail and not cond else ""))
    if not cond:
        failures.append(label)


def q(axis, deg):
    h = math.radians(deg) / 2
    v = {"x": 0, "y": 0, "z": 0}
    v[axis] = math.sin(h)
    return [v["x"], v["y"], v["z"], math.cos(h)]


def main():
    handler = functools.partial(http.server.SimpleHTTPRequestHandler, directory=str(ROOT / "dist"))
    handler.log_message = lambda *a: None
    server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{server.server_address[1]}"

    with sync_playwright() as p:
        browser = p.chromium.launch(args=["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"])
        for label, (fname, url) in MODELS.items():
            path = ROOT / "tests" / "models" / fname
            if not path.exists():
                print(f"downloading {fname}")
                urllib.request.urlretrieve(url, path)
            print(f"\n{label}  {fname}")
            page = browser.new_page(viewport={"width": 420, "height": 560})
            errors = []
            page.on("pageerror", lambda e: errors.append(str(e)))
            page.route(lambda u: urllib.parse.urlparse(u).path == "/__model.vrm", lambda r, _req, path=path: r.fulfill(path=str(path), content_type="model/gltf-binary"))
            page.goto(f"{base}/index.html?model=/__model.vrm")
            page.wait_for_function("window.__puppet && window.__puppet.bone('head') !== null", timeout=90000)

            def settle(frame=None, rest=False):
                if rest:
                    page.evaluate("window.__puppet.rest()")
                if frame is not None:
                    page.evaluate("f => window.__puppet.push(f)", {"bones": frame, "blends": {}})
                page.evaluate("window.__puppet.step(40)")

            def pos(name):
                return page.evaluate("n => window.__puppet.bone(n)", name)

            check(page.evaluate("window.__puppet.convention()") == ("mirrorZ" if label == "VRM0" else "mirrorX"), "convention follows VRM version")
            settle(rest=True)
            page.screenshot(timeout=180000, path=str(SHOTS / f"{label}-rest.png"))

            toes, foot = pos("leftToes"), pos("leftFoot")
            if toes and foot:
                check(toes[2] > foot[2] + 0.02, "faces the camera (+Z)", f"toes z {toes[2]:.3f} vs foot z {foot[2]:.3f}")
            lh, rh = pos("leftHand"), pos("rightHand")
            check(lh[0] > 0 > rh[0], "character's left is on +X", f"{lh[0]:.2f}, {rh[0]:.2f}")
            rest_lh, rest_rh = lh, rh
            rest_head = pos("head")

            # Arms: T-pose (identity) must be higher than the relaxed rest pose, each on its own side.
            settle({"LeftUpperArm": [0, 0, 0, 1], "RightUpperArm": [0, 0, 0, 1], "LeftLowerArm": [0, 0, 0, 1], "RightLowerArm": [0, 0, 0, 1]})
            lh, rh = pos("leftHand"), pos("rightHand")
            check(lh[1] > rest_lh[1] + 0.25 and rh[1] > rest_rh[1] + 0.25, "identity input raises arms to a T-pose")
            check(lh[0] > rest_lh[0] and rh[0] < rest_rh[0], "T-pose spreads arms outward")
            page.screenshot(timeout=180000, path=str(SHOTS / f"{label}-tpose.png"))

            # Elbows flex forward (+Z). Unity: left +Y, right -Y.
            settle({"LeftUpperArm": q("z", 62), "RightUpperArm": q("z", -62), "LeftLowerArm": q("y", 0), "RightLowerArm": q("y", 0)}, rest=False)
            lh0, rh0 = pos("leftHand"), pos("rightHand")
            le0, re0 = pos("leftLowerArm"), pos("rightLowerArm")
            settle({"LeftLowerArm": q("y", 80), "RightLowerArm": q("y", -80)})
            lh1, rh1 = pos("leftHand"), pos("rightHand")
            check(lh1[2] - le0[2] > lh0[2] - le0[2] + 0.12, "left elbow flex brings hand forward")
            check(rh1[2] - re0[2] > rh0[2] - re0[2] + 0.12, "right elbow flex brings hand forward")
            page.screenshot(timeout=180000, path=str(SHOTS / f"{label}-elbows.png"))

            # Torso leans forward.
            settle({"LeftLowerArm": q("y", 0), "RightLowerArm": q("y", 0), "Spine": q("x", 0)})
            h0 = pos("head")
            settle({"Spine": q("x", 25)})
            h1 = pos("head")
            check(h1[2] > h0[2] + 0.04, "spine pitch leans forward", f"head z {h0[2]:.3f} → {h1[2]:.3f}")

            # Legs and hips. Unity: thigh forward is -X, knee flex is +X, hips +Y turns toward the character's right.
            settle({"LeftUpperLeg": q("x", 0), "LeftLowerLeg": q("x", 0), "Hips": q("y", 0)})
            f0, k0 = pos("leftFoot"), pos("leftLowerLeg")
            settle({"LeftUpperLeg": q("x", -70)})
            f1 = pos("leftFoot")
            check(f1[2] > f0[2] + 0.2, "thigh raise swings the foot forward", f"foot z {f0[2]:.2f} → {f1[2]:.2f}")
            settle({"LeftUpperLeg": q("x", 0), "LeftLowerLeg": q("x", 60)})
            f2, k2 = pos("leftFoot"), pos("leftLowerLeg")
            check((f2[2] - k2[2]) < (f0[2] - k0[2]) - 0.15, "knee flex swings the shin backward")
            settle({"LeftLowerLeg": q("x", 0), "Hips": q("y", 30)})
            a, b = pos("leftUpperLeg"), pos("rightUpperLeg")
            line = [a[i] - b[i] for i in range(3)]
            check(line[2] / math.hypot(*line) > 0.3, "hips yaw turns toward character's right", f"hip line z {line[2] / math.hypot(*line):.2f} (expect ≈0.5)")
            settle({"Hips": q("y", 0)})

            # Head turns toward the character's right (+Y in Unity). Eye line (right eye → left eye)
            # starts along +X; a 35° turn toward the character's right swings it toward +Z.
            settle({"Spine": q("x", 0), "Head": q("y", 35)})
            le, re_ = pos("leftEye"), pos("rightEye")
            if le and re_:
                line = [le[i] - re_[i] for i in range(3)]
                n = math.hypot(*line)
                check(line[2] / n > 0.4, "head yaw turns toward character's right", f"eye line z {line[2] / n:.2f} (expect ≈0.57)")
            page.screenshot(timeout=180000, path=str(SHOTS / f"{label}-headturn.png"))

            # A real SelfReflect frame (fixtures/selfreflect.jsonl): just must render without errors.
            import json
            rec = [json.loads(l) for l in (ROOT / "fixtures" / "selfreflect.jsonl").read_text().splitlines() if l]
            frame = rec[12]["frame"]
            page.evaluate("f => window.__puppet.push(f)", frame)
            page.evaluate("window.__puppet.step(40)")
            page.screenshot(timeout=180000, path=str(SHOTS / f"{label}-selfreflect.png"))

            page.evaluate("window.__puppet.zoom(1)")
            page.evaluate("window.__puppet.step(5)")
            page.screenshot(timeout=180000, path=str(SHOTS / f"{label}-fullbody.png"))

            check(not errors, "no page errors", "; ".join(errors))
            page.close()

        # Settings menu: right-click opens it; background and mirror apply and survive a reload.
        print("\nUI")
        page = browser.new_page(viewport={"width": 420, "height": 560})
        page.goto(f"{base}/index.html")
        page.wait_for_selector("#open:not([hidden])")
        check(page.is_visible("#open"), "empty state shows the open target")
        check(page.is_hidden("#menu"), "menu starts hidden")
        page.mouse.click(200, 200, button="right")
        check(page.is_visible("#menu"), "right-click opens the menu")
        page.click("[data-bg=green]")
        check(page.evaluate("document.body.dataset.bg") == "green", "background switches to green")
        page.click("#mirror")
        check("scaleX(-1)" in page.evaluate("document.getElementById('stage').style.transform"), "mirror flips the stage")
        page.keyboard.press("Escape")
        page.mouse.move(200, 200)
        page.mouse.wheel(0, 600)
        page.wait_for_timeout(800)
        zoom = page.evaluate("JSON.parse(localStorage.getItem('settings')).zoom")
        check(0.8 < zoom <= 1, "scrolling zooms out and saves it", f"zoom {zoom}")
        check(page.is_hidden("#menu"), "Escape closes the menu")
        page.reload()
        page.wait_for_selector("#open")
        page.wait_for_function("document.body.dataset.bg === 'green'")
        check("scaleX(-1)" in page.evaluate("document.getElementById('stage').style.transform"), "settings persist across reload")
        page.close()
        browser.close()
    server.shutdown()
    print("\n" + ("ALL PASSED" if not failures else f"{len(failures)} FAILED: {failures}"))
    sys.exit(1 if failures else 0)


main()
