import { describe, expect, it } from 'vitest';
import { BONES, REST_POSE, axisAngle, convertQuat, conventionFor, type Quat4 } from '../src/vmc';

/** Rotate vector v by quaternion q (x, y, z, w). */
function rotate([qx, qy, qz, qw]: Quat4, [vx, vy, vz]: [number, number, number]): [number, number, number] {
  const tx = 2 * (qy * vz - qz * vy);
  const ty = 2 * (qz * vx - qx * vz);
  const tz = 2 * (qx * vy - qy * vx);
  return [vx + qw * tx + (qy * tz - qz * ty), vy + qw * ty + (qz * tx - qx * tz), vz + qw * tz + (qx * ty - qy * tx)];
}

const close = (a: number[], b: number[]) => a.forEach((v, i) => expect(v).toBeCloseTo(b[i] ?? NaN, 5));

describe('convertQuat', () => {
  it('VRM 1.0 (faces +Z): a Unity left-elbow flex ends pointing forward', () => {
    // Unity: left arm along -X, +90° about Y swings it to +Z.
    const unity = axisAngle('y', 90);
    close(rotate(unity, [-1, 0, 0]), [0, 0, 1]);
    // glTF 1.0: left arm along +X, forward is +Z.
    close(rotate(convertQuat(unity, 'mirrorX'), [1, 0, 0]), [0, 0, 1]);
  });

  it('VRM 0.x (faces -Z): the same flex ends pointing forward (-Z)', () => {
    const unity = axisAngle('y', 90);
    close(rotate(convertQuat(unity, 'mirrorZ'), [-1, 0, 0]), [0, 0, -1]);
  });

  it('is unit length with w ≥ 0, even for negative-w input', () => {
    const q = convertQuat([0.022, -0.055, 0.055, -0.997], 'mirrorX');
    expect(Math.hypot(...q)).toBeCloseTo(1, 6);
    expect(q[3]).toBeGreaterThanOrEqual(0);
  });

  it('never returns NaN: garbage becomes identity', () => {
    expect(convertQuat([NaN, 0, 0, 1], 'mirrorX')).toEqual([0, 0, 0, 1]);
    expect(convertQuat([0, 0, 0, 0], 'mirrorZ')).toEqual([0, 0, 0, 1]);
  });

  it('picks the convention from the VRM version', () => {
    expect(conventionFor('0')).toBe('mirrorZ');
    expect(conventionFor('1')).toBe('mirrorX');
  });
});

describe('BONES', () => {
  it('maps every humanoid bone a VMC sender transmits', () => {
    expect(Object.keys(BONES)).toHaveLength(54);
    expect(BONES.Hips).toBe('hips');
    expect(BONES.Spine).toBe('spine');
    expect(BONES.LeftUpperArm).toBe('leftUpperArm');
    expect(BONES.RightLittleDistal).toBe('rightLittleDistal');
    expect(BONES.LeftUpperLeg).toBe('leftUpperLeg');
    expect(BONES.RightToes).toBe('rightToes');
    expect(BONES.OriginalHips).toBeUndefined(); // not a humanoid bone
  });

  it('shifts the thumb chain to VRM 1.0 names', () => {
    expect(BONES.LeftThumbProximal).toBe('leftThumbMetacarpal');
    expect(BONES.LeftThumbIntermediate).toBe('leftThumbProximal');
    expect(BONES.RightThumbDistal).toBe('rightThumbDistal');
  });
});

describe('REST_POSE', () => {
  it('lowers both arms under either convention', () => {
    for (const c of ['mirrorX', 'mirrorZ'] as const) {
      const left = c === 'mirrorX' ? [1, 0, 0] : [-1, 0, 0]; // character's left arm direction
      const right = left.map((v) => -v) as [number, number, number];
      expect(rotate(convertQuat(REST_POSE.LeftUpperArm!, c), left as [number, number, number])[1]).toBeLessThan(-0.5);
      expect(rotate(convertQuat(REST_POSE.RightUpperArm!, c), right)[1]).toBeLessThan(-0.5);
    }
  });
});
