import { describe, expect, it } from 'vitest';
import { CALIBRATED, applyNeutral, averageQuats, neutralFrom } from '../src/calibration';
import { axisAngle, type Frame, type Quat4 } from '../src/vmc';

const frame = (bones: Record<string, Quat4>): Frame => ({ bones, blends: { jawOpen: 0.3 } });
const near = (a: Quat4, b: Quat4) => {
  const dot = Math.abs(a[0] * b[0] + a[1] * b[1] + a[2] * b[2] + a[3] * b[3]);
  expect(dot).toBeCloseTo(1, 6); // same rotation, either sign
};

describe('averageQuats', () => {
  it('averages nearby rotations', () => {
    near(averageQuats([axisAngle('z', 4), axisAngle('z', 6)]), axisAngle('z', 5));
  });

  it('treats q and -q as the same rotation', () => {
    const a = axisAngle('x', 10);
    const flipped: Quat4 = [-a[0], -a[1], -a[2], -a[3]];
    near(averageQuats([a, flipped, a]), a);
  });

  it('empty input is identity', () => {
    expect(averageQuats([])).toEqual([0, 0, 0, 1]);
  });
});

describe('neutralFrom / applyNeutral', () => {
  const tilted = frame({ Head: axisAngle('z', 6), Chest: axisAngle('z', -2), Hips: axisAngle('y', 3) });

  it('makes the calibrated pose read as straight', () => {
    const neutral = neutralFrom([tilted, tilted, tilted]);
    const out = applyNeutral(tilted, neutral);
    for (const bone of ['Head', 'Chest', 'Hips']) near(out.bones[bone]!, [0, 0, 0, 1]);
  });

  it('offsets later movement by the neutral, not by nothing', () => {
    const neutral = neutralFrom([tilted]);
    // 6° tilt at calibration, 16° now → 10° remains.
    const now = applyNeutral(frame({ Head: axisAngle('z', 16) }), neutral);
    near(now.bones.Head!, axisAngle('z', 10));
  });

  it('only touches the posture chain and keeps everything else', () => {
    const f = frame({ Head: axisAngle('z', 6), LeftUpperArm: axisAngle('z', 60), LeftUpperLeg: axisAngle('x', -50) });
    const out = applyNeutral(f, neutralFrom([f]));
    expect(out.bones.LeftUpperArm).toEqual(f.bones.LeftUpperArm);
    expect(out.bones.LeftUpperLeg).toEqual(f.bones.LeftUpperLeg);
    expect(out.blends).toEqual(f.blends);
    expect(Object.keys(neutralFrom([f]))).toEqual(['Head']);
    expect(CALIBRATED).not.toContain('LeftUpperArm');
  });

  it('is a no-op without a neutral, and skips bones the frame lacks', () => {
    expect(applyNeutral(tilted, undefined)).toBe(tilted);
    const out = applyNeutral(frame({ Spine: axisAngle('x', 5) }), neutralFrom([tilted]));
    expect(out.bones.Spine).toEqual(axisAngle('x', 5));
  });

  it('never mutates its input', () => {
    const f = frame({ Head: axisAngle('z', 6) });
    const copy = JSON.parse(JSON.stringify(f));
    applyNeutral(f, neutralFrom([f]));
    expect(f).toEqual(copy);
  });

  it('returns unit, w >= 0 rotations', () => {
    const out = applyNeutral(frame({ Head: [-0.1, 0.2, -0.3, -0.9] }), neutralFrom([tilted]));
    expect(Math.hypot(...out.bones.Head!)).toBeCloseTo(1, 6);
    expect(out.bones.Head![3]).toBeGreaterThanOrEqual(0);
  });
});
