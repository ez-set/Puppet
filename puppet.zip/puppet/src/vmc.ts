import type { VRMHumanBoneName } from '@pixiv/three-vrm';

/** Quaternion as x, y, z, w. */
export type Quat4 = [number, number, number, number];

/** Latest pose from a VMC sender: Unity humanoid bone name → local rotation, ARKit blendshape → weight. */
export interface Frame {
  bones: Record<string, Quat4>;
  blends: Record<string, number>;
}

export interface Status {
  addr: string;
  live: boolean;
  error: string | null;
}

/** How VMC (Unity, left-handed, model faces +Z) rotations map into a model's own space. */
export type Convention = 'mirrorX' | 'mirrorZ';

/** VRM 1.0 models face +Z in glTF space (mirror X); VRM 0.x models face -Z (mirror Z). */
export function conventionFor(metaVersion: string): Convention {
  return metaVersion === '0' ? 'mirrorZ' : 'mirrorX';
}

/** Mirror a Unity rotation into model space; unit length, w ≥ 0. Invalid input → identity. */
export function convertQuat([x, y, z, w]: Quat4, convention: Convention): Quat4 {
  const [cx, cy, cz] = convention === 'mirrorX' ? [x, -y, -z] : [-x, -y, z];
  const len = Math.hypot(cx, cy, cz, w);
  if (!Number.isFinite(len) || len < 1e-6) return [0, 0, 0, 1];
  const s = w < 0 ? -1 / len : 1 / len;
  return [cx * s, cy * s, cz * s, w * s];
}

const lower = (s: string) => s.charAt(0).toLowerCase() + s.slice(1);

/**
 * Unity humanoid bone → VRM humanoid bone: every humanoid bone VMC senders transmit.
 * Rotations only; the hips never move. three-vrm names bones the VRM 1.0 way for
 * both model versions, so the thumb chain shifts by one (Proximal → Metacarpal).
 */
export const BONES: Record<string, VRMHumanBoneName> = (() => {
  const map: Record<string, string> = {};
  for (const b of ['Hips', 'Spine', 'Chest', 'UpperChest', 'Neck', 'Head']) map[b] = lower(b);
  for (const side of ['Left', 'Right']) {
    for (const b of ['Eye', 'Shoulder', 'UpperArm', 'LowerArm', 'Hand', 'UpperLeg', 'LowerLeg', 'Foot', 'Toes'])
      map[side + b] = lower(side + b);
    for (const f of ['Index', 'Middle', 'Ring', 'Little'])
      for (const seg of ['Proximal', 'Intermediate', 'Distal']) map[side + f + seg] = lower(side + f + seg);
    map[`${side}ThumbProximal`] = lower(`${side}ThumbMetacarpal`);
    map[`${side}ThumbIntermediate`] = lower(`${side}ThumbProximal`);
    map[`${side}ThumbDistal`] = lower(`${side}ThumbDistal`);
  }
  return map as Record<string, VRMHumanBoneName>;
})();

/** Unity-convention rotation of `deg` degrees about a coordinate axis. */
export function axisAngle(axis: 'x' | 'y' | 'z', deg: number): Quat4 {
  const h = (deg * Math.PI) / 360;
  const s = Math.sin(h);
  return [axis === 'x' ? s : 0, axis === 'y' ? s : 0, axis === 'z' ? s : 0, Math.cos(h)];
}

/** Relaxed pose shown before a sender connects: arms down, a little elbow bend. */
export const REST_POSE: Record<string, Quat4> = {
  LeftUpperArm: axisAngle('z', 62),
  RightUpperArm: axisAngle('z', -62),
  LeftLowerArm: axisAngle('y', 12),
  RightLowerArm: axisAngle('y', -12),
};
