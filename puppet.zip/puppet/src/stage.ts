import * as THREE from 'three';
import type { Avatar } from './avatar';

const FOV = 24;

export class Stage {
  private readonly renderer: THREE.WebGLRenderer;
  private readonly scene = new THREE.Scene();
  private readonly camera = new THREE.PerspectiveCamera(FOV, 1, 0.05, 50);
  private avatar: Avatar | null = null;
  private zoom = 0;

  constructor(private readonly canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
    this.renderer.setClearColor(0x000000, 0);
    this.scene.add(new THREE.AmbientLight(0xffffff, 0.7));
    const key = new THREE.DirectionalLight(0xffffff, 2.2);
    key.position.set(0.8, 1.6, 2.4);
    this.scene.add(key);
    this.camera.position.set(0, 1.2, 2.5);
    new ResizeObserver(() => this.resize()).observe(canvas);
    this.resize();
  }

  setAvatar(avatar: Avatar | null): void {
    if (this.avatar) this.scene.remove(this.avatar.scene);
    this.avatar = avatar;
    if (!avatar) return;
    this.scene.add(avatar.scene);
    this.frame(avatar);
  }

  /** 0 = bust-up, 1 = full body. */
  setZoom(zoom: number): void {
    this.zoom = Math.min(1, Math.max(0, zoom));
    if (this.avatar) this.frame(this.avatar);
  }

  /** Framing from the model's height: top of the hair down to mid-torso (zoom 0) or the feet (zoom 1). */
  private frame(avatar: Avatar): void {
    const box = new THREE.Box3().setFromObject(avatar.scene);
    const total = box.max.y - box.min.y;
    if (!(total > 0.1)) return;
    const top = box.max.y + 0.04 * total;
    const bust = box.max.y - 0.44 * total;
    const feet = box.min.y - 0.03 * total;
    const bottom = bust + (feet - bust) * this.zoom;
    const height = top - bottom;
    const centerY = (top + bottom) / 2;
    const tan = Math.tan((FOV * Math.PI) / 360);
    const fitHeight = height / 2 / tan;
    const fitWidth = (height * 1.1) / 2 / (this.camera.aspect * tan);
    this.camera.position.set(0, centerY, Math.max(fitHeight, fitWidth));
    this.camera.lookAt(0, centerY, 0);
  }

  render(): void {
    this.renderer.render(this.scene, this.camera);
  }

  private resize(): void {
    const { clientWidth: w, clientHeight: h } = this.canvas;
    if (!w || !h) return;
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    if (this.avatar) this.frame(this.avatar);
  }
}
