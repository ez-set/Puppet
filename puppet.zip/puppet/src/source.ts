import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import type { Neutral } from './calibration';
import type { Frame, Status } from './vmc';

export const inTauri = '__TAURI_INTERNALS__' in window;

export interface Settings {
  port: number;
  background: 'dark' | 'green' | 'clear';
  mirror: boolean;
  /** 0 = bust-up, 1 = full body. */
  zoom: number;
  /** Hold the pelvis level (seated streaming). */
  seated: boolean;
  model: string | null;
  /** Calibrated neutral posture; empty when not calibrated. */
  neutral: Neutral;
}

const DEFAULTS: Settings = { port: 39539, background: 'dark', mirror: false, zoom: 0, seated: false, model: null, neutral: {} };

export async function getSettings(): Promise<Settings> {
  if (inTauri) return invoke<Settings>('settings_get');
  try {
    return { ...DEFAULTS, ...JSON.parse(localStorage.getItem('settings') ?? '{}') };
  } catch {
    return DEFAULTS;
  }
}

export async function saveSettings(s: Settings): Promise<void> {
  if (inTauri) await invoke('settings_set', { settings: s });
  else localStorage.setItem('settings', JSON.stringify(s));
}

/** A model is a file path in the app, a URL in the browser. */
export async function readModel(src: string): Promise<ArrayBuffer> {
  if (inTauri) return invoke<ArrayBuffer>('load_model', { path: src });
  const res = await fetch(src);
  if (!res.ok) throw new Error(`${src}: ${res.status}`);
  return res.arrayBuffer();
}

export async function pickModel(): Promise<string | File | null> {
  if (inTauri) return invoke<string | null>('pick_model');
  return new Promise((resolve) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.vrm';
    input.onchange = () => resolve(input.files?.[0] ?? null);
    input.click();
  });
}

export function onDrop(cb: (model: string | File) => void): void {
  if (inTauri) {
    void listen<string>('drop', (e) => cb(e.payload));
    return;
  }
  addEventListener('dragover', (e) => e.preventDefault());
  addEventListener('drop', (e) => {
    e.preventDefault();
    const file = e.dataTransfer?.files[0];
    if (file) cb(file);
  });
}

export function onFrame(cb: (frame: Frame) => void): void {
  if (inTauri) void listen<Frame>('frame', (e) => cb(e.payload));
}

export function onStatus(cb: (status: Status) => void): void {
  if (inTauri) {
    void listen<Status>('status', (e) => cb(e.payload));
    return;
  }
  cb({ addr: '127.0.0.1:39539', live: false, error: null });
}

/** Browser only: loop a recording (one `{t, frame}` JSON object per line). */
export async function replay(url: string, cb: (frame: Frame) => void): Promise<void> {
  const text = await (await fetch(url)).text();
  const lines = text
    .split('\n')
    .filter(Boolean)
    .map((l) => JSON.parse(l) as { t: number; frame: Frame });
  const run = () => {
    for (const { t, frame } of lines) setTimeout(() => cb(frame), t);
    setTimeout(run, (lines.at(-1)?.t ?? 0) + 16);
  };
  run();
}
