/** ARKit blendshape weights → VRM expression weights. */

const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');

/** The 52 ARKit blendshape names, normalized. */
const ARKIT = new Set(
  `browDownLeft browDownRight browInnerUp browOuterUpLeft browOuterUpRight cheekPuff cheekSquintLeft
   cheekSquintRight eyeBlinkLeft eyeBlinkRight eyeLookDownLeft eyeLookDownRight eyeLookInLeft eyeLookInRight
   eyeLookOutLeft eyeLookOutRight eyeLookUpLeft eyeLookUpRight eyeSquintLeft eyeSquintRight eyeWideLeft
   eyeWideRight jawForward jawLeft jawOpen jawRight mouthClose mouthDimpleLeft mouthDimpleRight
   mouthFrownLeft mouthFrownRight mouthFunnel mouthLeft mouthLowerDownLeft mouthLowerDownRight
   mouthPressLeft mouthPressRight mouthPucker mouthRight mouthRollLower mouthRollUpper mouthShrugLower
   mouthShrugUpper mouthSmileLeft mouthSmileRight mouthStretchLeft mouthStretchRight mouthUpperUpLeft
   mouthUpperUpRight noseSneerLeft noseSneerRight tongueOut`
    .split(/\s+/)
    .map((n) => n.toLowerCase()),
);

/** A model with this many ARKit-named expressions is treated as "perfect sync". */
const PERFECT_SYNC_MIN = 12;

/**
 * `available` is the model's expression names. Perfect-sync models get ARKit weights
 * straight through; others get blink and mouth shapes mapped onto the VRM presets.
 */
export function expressionWeights(
  blends: Record<string, number>,
  available: readonly string[],
): Record<string, number> {
  const arkitNamed = available.filter((n) => ARKIT.has(norm(n)));
  if (arkitNamed.length >= PERFECT_SYNC_MIN) {
    const byNorm = new Map(Object.entries(blends).map(([k, v]) => [norm(k), v]));
    const direct: Record<string, number> = {};
    for (const name of arkitNamed) {
      const v = byNorm.get(norm(name));
      if (v !== undefined) direct[name] = clamp01(v);
    }
    return direct;
  }

  const b = (k: string) => blends[k] ?? 0;
  const avg = (a: string, c: string) => (b(a) + b(c)) / 2;
  const has = (n: string) => available.includes(n);

  const out: Record<string, number> = {
    aa: b('jawOpen') * (1 - 0.5 * Math.max(b('mouthPucker'), b('mouthFunnel'))),
    ih: avg('mouthStretchLeft', 'mouthStretchRight') * 0.6,
    ou: b('mouthPucker'),
    oh: b('mouthFunnel'),
    ee: avg('mouthSmileLeft', 'mouthSmileRight') * 0.5,
  };
  if (has('blinkLeft') && has('blinkRight')) {
    out.blinkLeft = b('eyeBlinkLeft');
    out.blinkRight = b('eyeBlinkRight');
  } else {
    out.blink = avg('eyeBlinkLeft', 'eyeBlinkRight');
  }
  for (const k of Object.keys(out)) out[k] = clamp01(out[k] ?? 0);
  return out;
}
