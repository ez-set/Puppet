import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { VRM, VRMLoaderPlugin, VRMUtils, type VRMHumanBoneName } from '@pixiv/three-vrm';
import { expressionWeights } from './expressions';
import { BONES, REST_POSE, convertQuat, conventionFor, type Convention, type Frame } from './vmc';

/** How quickly bones follow the incoming pose (higher = snappier). */
const FOLLOW_RATE = 28;

interface Driven {
  unity: string;
  node: THREE.Object3D;
  target: THREE.Quaternion;
}

export class Avatar {
  readonly scene: THREE.Object3D;
  readonly convention: Convention;
  private readonly driven: Driven[] = [];
  private readonly expressionNames: string[];
  private lit: string[] = [];

  private constructor(private readonly vrm: VRM) {
    this.scene = vrm.scene;
    this.convention = conventionFor(vrm.meta.metaVersion);
    this.expressionNames = Object.keys(vrm.expressionManager?.expressionMap ?? {});
    for (const [unity, name] of Object.entries(BONES)) {
      const node = vrm.humanoid.getNormalizedBoneNode(name);
      if (node) this.driven.push({ unity, node, target: new THREE.Quaternion() });
    }
    this.setFrame(null);
    for (const d of this.driven) d.node.quaternion.copy(d.target);
    this.vrm.update(0);
  }

  static async load(data: ArrayBuffer): Promise<Avatar> {
    const loader = new GLTFLoader();
    loader.register((parser) => new VRMLoaderPlugin(parser));
    const gltf = await loader.parseAsync(data, '');
    const vrm = gltf.userData.vrm as VRM | undefined;
    if (!vrm) throw new Error('not a VRM file');
    VRMUtils.removeUnnecessaryVertices(gltf.scene);
    VRMUtils.combineSkeletons(gltf.scene);
    VRMUtils.rotateVRM0(vrm); // VRM 0.x faces -Z; turn it to face the camera
    vrm.scene.traverse((o) => (o.frustumCulled = false));
    return new Avatar(vrm);
  }

  /** Aim at a pose. `null` relaxes to the rest pose. */
  setFrame(frame: Frame | null): void {
    for (const d of this.driven) {
      const q = frame ? frame.bones[d.unity] : (REST_POSE[d.unity] ?? [0, 0, 0, 1]);
      if (q) d.target.set(...convertQuat(q, this.convention));
    }
    this.setExpressions(frame ? expressionWeights(frame.blends, this.expressionNames) : {});
  }

  private setExpressions(weights: Record<string, number>): void {
    const mgr = this.vrm.expressionManager;
    if (!mgr) return;
    for (const name of this.lit) if (!(name in weights)) mgr.setValue(name, 0);
    for (const [name, v] of Object.entries(weights)) mgr.setValue(name, v);
    this.lit = Object.keys(weights);
  }

  update(dt: number): void {
    const alpha = 1 - Math.exp(-FOLLOW_RATE * dt);
    for (const d of this.driven) d.node.quaternion.slerp(d.target, alpha);
    this.vrm.update(dt);
  }

  /** World position of a bone on the visible skeleton. */
  bonePosition(name: VRMHumanBoneName): THREE.Vector3 | null {
    const node = this.vrm.humanoid.getRawBoneNode(name);
    if (!node) return null;
    node.updateWorldMatrix(true, false);
    return node.getWorldPosition(new THREE.Vector3());
  }

  dispose(): void {
    VRMUtils.deepDispose(this.vrm.scene);
  }
}
