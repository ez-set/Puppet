import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { VRM, VRMLoaderPlugin, VRMUtils, type VRMHumanBoneName } from '@pixiv/three-vrm';
import { expressionWeights } from './expressions';
import { BONES, REST_POSE, convertQuat, conventionFor, type Convention, type Frame } from './vmc';

/** How quickly bones follow the incoming pose (higher = snappier). */
const FOLLOW_RATE = 28;

interface Driven {
  unity: string;
  node: THREE.Object3D;
  target: THREE.Quaternion;
  /** Smoothed pose before any correction, so corrections never feed back into the smoothing. */
  raw: THREE.Quaternion;
}

const UP = new THREE.Vector3(0, 1, 0);
const FORWARD = new THREE.Vector3(0, 0, 1);

export class Avatar {
  readonly scene: THREE.Object3D;
  readonly convention: Convention;
  private readonly driven: Driven[] = [];
  private readonly expressionNames: string[];
  private lit: string[] = [];
  private readonly feet: THREE.Object3D[] = [];
  private hips: THREE.Object3D | null = null;
  private readonly hipChildren: THREE.Object3D[] = [];
  /** Seated: keep the pelvis level; the spine carries any sway. */
  seated = false;
  private readonly restWorld = new THREE.Quaternion();
  private readonly scratch = {
    parent: new THREE.Quaternion(),
    delta: new THREE.Quaternion(),
    flat: new THREE.Quaternion(),
    restInverse: new THREE.Quaternion(),
    twist: new THREE.Quaternion(),
    swing: new THREE.Quaternion(),
    forward: new THREE.Vector3(),
  };

  private constructor(private readonly vrm: VRM) {
    this.scene = vrm.scene;
    this.convention = conventionFor(vrm.meta.metaVersion);
    this.expressionNames = Object.keys(vrm.expressionManager?.expressionMap ?? {});
    for (const [unity, name] of Object.entries(BONES)) {
      const node = vrm.humanoid.getNormalizedBoneNode(name);
      if (node) this.driven.push({ unity, node, target: new THREE.Quaternion(), raw: new THREE.Quaternion() });
    }
    vrm.scene.getWorldQuaternion(this.restWorld);
    this.scratch.restInverse.copy(this.restWorld).invert();
    for (const d of this.driven) {
      if (d.unity === 'LeftFoot' || d.unity === 'RightFoot') this.feet.push(d.node);
      if (d.unity === 'Hips') this.hips = d.node;
      if (d.unity === 'Spine' || d.unity === 'LeftUpperLeg' || d.unity === 'RightUpperLeg') this.hipChildren.push(d.node);
    }
    this.setFrame(null);
    for (const d of this.driven) {
      d.node.quaternion.copy(d.target);
      d.raw.copy(d.target);
    }
    this.vrm.update(0);
  }

  static async load(data: ArrayBuffer): Promise<Avatar> {
    const loader = new GLTFLoader();
    loader.register((parser) => new VRMLoaderPlugin(parser));
    const gltf = await loader.parseAsync(data, '');
    const vrm = gltf.userData.vrm as VRM | undefined;
    if (!vrm) throw new Error('not a VRM file');
    VRMUtils.removeUnnecessaryVertices(gltf.scene);
    VRMUtils.combineSkeletons(gltf.scene);
    VRMUtils.rotateVRM0(vrm); // VRM 0.x faces -Z; turn it to face the camera
    vrm.scene.traverse((o) => (o.frustumCulled = false));
    return new Avatar(vrm);
  }

  /** Aim at a pose. `null` relaxes to the rest pose. */
  setFrame(frame: Frame | null): void {
    for (const d of this.driven) {
      const q = frame ? frame.bones[d.unity] : (REST_POSE[d.unity] ?? [0, 0, 0, 1]);
      if (q) d.target.set(...convertQuat(q, this.convention));
    }
    this.setExpressions(frame ? expressionWeights(frame.blends, this.expressionNames) : {});
  }

  private setExpressions(weights: Record<string, number>): void {
    const mgr = this.vrm.expressionManager;
    if (!mgr) return;
    for (const name of this.lit) if (!(name in weights)) mgr.setValue(name, 0);
    for (const [name, v] of Object.entries(weights)) mgr.setValue(name, v);
    this.lit = Object.keys(weights);
  }

  update(dt: number): void {
    const alpha = 1 - Math.exp(-FOLLOW_RATE * dt);
    for (const d of this.driven) {
      d.raw.slerp(d.target, alpha);
      d.node.quaternion.copy(d.raw);
    }
    if (this.seated) this.levelHips();
    this.levelFeet();
    this.vrm.update(dt);
  }

  /**
   * Hold the pelvis level. The hips rotation splits into a turn about the vertical axis (kept)
   * and a tilt (removed). The tilt is handed to the spine and thighs instead, so each keeps the
   * world orientation the sender gave it. Only the pelvis itself stops tipping.
   */
  private levelHips(): void {
    const hips = this.hips;
    if (!hips) return;
    const { twist, swing } = this.scratch;
    const q = hips.quaternion;
    twist.set(0, q.y, 0, q.w);
    if (twist.lengthSq() < 1e-8) return; // a half-turn tilt has no defined heading; leave it
    twist.normalize();
    swing.copy(twist).invert().multiply(q);
    hips.quaternion.copy(twist);
    for (const child of this.hipChildren) child.quaternion.premultiply(swing);
  }

  /**
   * Keep the feet flat on the floor. Camera-based senders guess foot pitch and roll, and the
   * guess is often several tens of degrees off, which points the toes up or down. Only the
   * heading (where the toes point) is kept.
   */
  private levelFeet(): void {
    const { scratch } = this;
    for (const foot of this.feet) {
      const parent = foot.parent;
      if (!parent) continue;
      parent.updateWorldMatrix(true, false);
      parent.getWorldQuaternion(scratch.parent);
      // Where the foot points now, as a rotation away from where it points at rest.
      scratch.delta.copy(scratch.parent).multiply(foot.quaternion).multiply(scratch.restInverse);
      scratch.forward.copy(FORWARD).applyQuaternion(scratch.delta);
      const heading = Math.atan2(scratch.forward.x, scratch.forward.z);
      scratch.flat.setFromAxisAngle(UP, heading).multiply(this.restWorld);
      foot.quaternion.copy(scratch.parent.invert().multiply(scratch.flat));
    }
  }

  /** World position of a bone on the visible skeleton. */
  bonePosition(name: VRMHumanBoneName): THREE.Vector3 | null {
    const node = this.vrm.humanoid.getRawBoneNode(name);
    if (!node) return null;
    node.updateWorldMatrix(true, false);
    return node.getWorldPosition(new THREE.Vector3());
  }

  dispose(): void {
    VRMUtils.deepDispose(this.vrm.scene);
  }
}
