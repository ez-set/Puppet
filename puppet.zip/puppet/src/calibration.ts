import type { Frame, Quat4 } from './vmc';

/** The posture chain. Arms and legs are not calibrated: they are not "neutral" when you sit. */
export const CALIBRATED = ['Hips', 'Spine', 'Chest', 'UpperChest', 'Neck', 'Head'] as const;

export type Neutral = Record<string, Quat4>;

const normalize = ([x, y, z, w]: Quat4): Quat4 => {
  const n = Math.hypot(x, y, z, w);
  return Number.isFinite(n) && n > 1e-6 ? [x / n, y / n, z / n, w / n] : [0, 0, 0, 1];
};

const multiply = ([ax, ay, az, aw]: Quat4, [bx, by, bz, bw]: Quat4): Quat4 => [
  aw * bx + ax * bw + ay * bz - az * by,
  aw * by - ax * bz + ay * bw + az * bx,
  aw * bz + ax * by - ay * bx + az * bw,
  aw * bw - ax * bx - ay * by - az * bz,
];

const inverse = ([x, y, z, w]: Quat4): Quat4 => [-x, -y, -z, w];

/** Mean rotation of a set of quaternions (q and −q are the same rotation, so signs are aligned first). */
export function averageQuats(quats: Quat4[]): Quat4 {
  const first = quats[0];
  if (!first) return [0, 0, 0, 1];
  const sum: Quat4 = [0, 0, 0, 0];
  for (const q of quats) {
    const sign = q[0] * first[0] + q[1] * first[1] + q[2] * first[2] + q[3] * first[3] < 0 ? -1 : 1;
    for (let i = 0; i < 4; i++) sum[i] = (sum[i] ?? 0) + sign * (q[i] ?? 0);
  }
  return normalize(sum);
}

/** The pose to treat as "straight": the average of the given frames. */
export function neutralFrom(frames: Frame[]): Neutral {
  const neutral: Neutral = {};
  for (const bone of CALIBRATED) {
    const quats = frames.map((f) => f.bones[bone]).filter((q): q is Quat4 => !!q);
    if (quats.length) neutral[bone] = averageQuats(quats.map(normalize));
  }
  return neutral;
}

/** Re-express the posture bones relative to the neutral pose, so the neutral pose reads as identity. */
export function applyNeutral(frame: Frame, neutral: Neutral | undefined): Frame {
  if (!neutral) return frame;
  const bones = { ...frame.bones };
  for (const bone of CALIBRATED) {
    const n = neutral[bone];
    const q = bones[bone];
    if (!n || !q) continue;
    const out = normalize(multiply(inverse(n), normalize(q)));
    bones[bone] = out[3] < 0 ? [-out[0], -out[1], -out[2], -out[3]] : out;
  }
  return { ...frame, bones };
}
