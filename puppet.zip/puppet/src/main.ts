import './style.css';
import { Avatar } from './avatar';
import { applyNeutral, neutralFrom } from './calibration';
import { Stage } from './stage';
import {
  getSettings, inTauri, onDrop, onFrame, onStatus, pickModel, readModel, replay, saveSettings,
  type Settings,
} from './source';
import type { Frame, Status } from './vmc';

const $ = <T extends HTMLElement>(id: string) => document.getElementById(id) as T;
const canvas = $<HTMLCanvasElement>('stage');
const openBtn = $<HTMLButtonElement>('open');
const chip = $<HTMLButtonElement>('chip');
const dot = $('dot');
const addr = $('addr');
const menu = $('menu');
const mirrorBtn = $<HTMLButtonElement>('mirror');
const calibrateBtn = $<HTMLButtonElement>('calibrate');
const resetBtn = $<HTMLButtonElement>('reset');

const stage = new Stage(canvas);
let avatar: Avatar | null = null;
let settings: Settings;
let status: Status = { addr: '', live: false, error: null };
let lastFrame: Frame | null = null;
/** Raw (uncalibrated) frames from the last moments, for calibration. */
const recent: { at: number; frame: Frame }[] = [];

function pose(frame: Frame | null): Frame | null {
  return frame ? applyNeutral(frame, settings.neutral) : null;
}

// ---------------------------------------------------------------- chip

function renderChip(): void {
  addr.textContent = status.error ?? status.addr;
  dot.dataset.state = status.error ? 'error' : status.live ? 'live' : 'idle';
}

function flash(text: string): void {
  addr.textContent = text;
  dot.dataset.state = 'error';
  wake();
  setTimeout(renderChip, 3500);
}

let quietTimer: number | undefined;
function wake(): void {
  chip.classList.remove('quiet');
  clearTimeout(quietTimer);
  if (status.live && !status.error) quietTimer = window.setTimeout(() => chip.classList.add('quiet'), 3000);
}
addEventListener('mousemove', wake);

chip.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(status.addr);
  } catch {
    const t = document.createElement('textarea');
    t.value = status.addr;
    document.body.append(t);
    t.select();
    document.execCommand('copy');
    t.remove();
  }
  chip.classList.remove('copied');
  void chip.offsetWidth;
  chip.classList.add('copied');
});

// ---------------------------------------------------------------- model

async function openModel(src: string | File): Promise<void> {
  try {
    const data = src instanceof File ? await src.arrayBuffer() : await readModel(src);
    const next = await Avatar.load(data);
    avatar?.dispose();
    avatar = next;
    stage.setAvatar(next);
    next.setFrame(status.live ? pose(lastFrame) : null);
    openBtn.hidden = true;
    if (typeof src === 'string' && inTauri) {
      settings.model = src;
      await saveSettings(settings);
    }
  } catch (e) {
    console.error(e);
    flash('can’t open that file');
  }
}

openBtn.addEventListener('click', async () => {
  const picked = await pickModel();
  if (picked) await openModel(picked);
});
onDrop((model) => void openModel(model));

// ---------------------------------------------------------------- settings menu

function applySettings(): void {
  document.body.dataset.bg = settings.background;
  canvas.style.transform = settings.mirror ? 'scaleX(-1)' : '';
  mirrorBtn.setAttribute('aria-pressed', String(settings.mirror));
  stage.setZoom(settings.zoom);
  resetBtn.hidden = Object.keys(settings.neutral).length === 0;
  avatar?.setFrame(status.live ? pose(lastFrame) : null);
  for (const b of menu.querySelectorAll<HTMLButtonElement>('[data-bg]'))
    b.setAttribute('aria-current', String(b.dataset.bg === settings.background));
}

function change(patch: Partial<Settings>): void {
  settings = { ...settings, ...patch };
  applySettings();
  void saveSettings(settings);
}

let zoomSave: number | undefined;
addEventListener(
  'wheel',
  (e) => {
    e.preventDefault();
    settings = { ...settings, zoom: Math.min(1, Math.max(0, settings.zoom + e.deltaY * 0.0015)) };
    stage.setZoom(settings.zoom);
    clearTimeout(zoomSave);
    zoomSave = window.setTimeout(() => void saveSettings(settings), 400);
  },
  { passive: false },
);

/** Treat the posture of the last half second as straight. */
function calibrate(windowMs = 500): boolean {
  const since = performance.now() - windowMs;
  const frames = recent.filter((r) => r.at >= since).map((r) => r.frame);
  if (!frames.length) return false;
  change({ neutral: neutralFrom(frames) });
  return true;
}

calibrateBtn.addEventListener('click', () => {
  menu.hidden = true; // out of the way, and out of the capture
  chip.classList.add('calibrating');
  window.setTimeout(() => {
    chip.classList.remove('calibrating');
    if (!calibrate()) flash('no data');
  }, 3000);
});
resetBtn.addEventListener('click', () => change({ neutral: {} }));

addEventListener('contextmenu', (e) => {
  e.preventDefault();
  menu.hidden = false;
  const { offsetWidth: w, offsetHeight: h } = menu;
  menu.style.left = `${Math.min(e.clientX, innerWidth - w - 8)}px`;
  menu.style.top = `${Math.min(e.clientY, innerHeight - h - 8)}px`;
});
addEventListener('pointerdown', (e) => {
  if (!menu.contains(e.target as Node)) menu.hidden = true;
});
addEventListener('keydown', (e) => e.key === 'Escape' && (menu.hidden = true));
menu.addEventListener('click', (e) => {
  const bg = (e.target as HTMLElement).closest<HTMLElement>('[data-bg]')?.dataset.bg;
  if (bg) change({ background: bg as Settings['background'] });
  if ((e.target as HTMLElement).closest('#mirror')) change({ mirror: !settings.mirror });
});

// ---------------------------------------------------------------- tracking

onFrame((frame) => {
  lastFrame = frame;
  recent.push({ at: performance.now(), frame });
  if (recent.length > 60) recent.shift();
  avatar?.setFrame(pose(frame));
});
onStatus((next) => {
  const changed = next.live !== status.live || next.error !== status.error || next.addr !== status.addr;
  const wasLive = status.live;
  status = next;
  renderChip();
  if (wasLive && !next.live) avatar?.setFrame(null);
  if (changed) wake(); // the periodic status tick must not keep the chip awake
});

// ---------------------------------------------------------------- loop

let last = performance.now();
function tick(now: number): void {
  avatar?.update(Math.min((now - last) / 1000, 0.05));
  last = now;
  stage.render();
  requestAnimationFrame(tick);
}

async function start(): Promise<void> {
  settings = await getSettings();
  applySettings();
  requestAnimationFrame(tick);

  if (!inTauri) {
    // Browser mode for development and tests: ?model=<url>&replay=<url>
    const q = new URLSearchParams(location.search);
    const model = q.get('model');
    if (model) await openModel(model);
    const rec = q.get('replay');
    if (rec) {
      status = { ...status, live: true };
      renderChip();
      void replay(rec, (f) => {
        lastFrame = f;
        recent.push({ at: performance.now(), frame: f });
        if (recent.length > 60) recent.shift();
        avatar?.setFrame(pose(f));
      });
    }
    Object.assign(window, {
      __puppet: {
        push: (f: Frame) => {
          status = { ...status, live: true };
          lastFrame = f;
          recent.push({ at: performance.now(), frame: f });
          if (recent.length > 60) recent.shift();
          avatar?.setFrame(pose(f));
        },
        calibrateLast: (n: number) => {
          change({ neutral: neutralFrom(recent.slice(-n).map((r) => r.frame)) });
          return true;
        },
        resetCalibration: () => change({ neutral: {} }),
        rest: () => avatar?.setFrame(null),
        step: (n = 30) => { for (let i = 0; i < n; i++) avatar?.update(0.05); },
        bone: (name: string) => avatar?.bonePosition(name as never)?.toArray() ?? null,
        convention: () => avatar?.convention ?? null,
        zoom: (z: number) => stage.setZoom(z),
      },
    });
  } else if (settings.model) {
    await openModel(settings.model);
  }
}
void start();
